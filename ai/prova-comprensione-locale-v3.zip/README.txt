PROVA DI COMPRENSIONE LOCALE V3 - HEALTHY SMILE

1. Estrai tutto lo ZIP in una nuova cartella sul PC Windows.
2. Apri Ollama (il modello previsto e' qwen3:4b, gia' usato dall'agente).
3. Fai doppio clic su PROVA-LOCALE.bat e attendi la fine dei tre casi.
4. Carica in chat il file risultato-prova-locale.json creato nella stessa cartella.

Servono Python 3 e Ollama, come per l'agente precedente.
Se manca il modello, il programma indica: ollama pull qwen3:4b.
La prima risposta puo' richiedere piu' tempo per caricare il modello.
Prima dei casi clinici viene eseguita una prova brevissima, limite 60 secondi.
Solo una risposta completa OK, senza ragionamento, consente di avviare i casi.
Viene aggiunto il comando /no_think previsto da Qwen3 per disattivare il
ragionamento: e' una richiesta al modello, non una garanzia di qualita'.
Ogni caso clinico ha un limite totale di 120 secondi. Ogni 10 secondi viene
mostrato il tempo trascorso e il numero di caratteri ricevuti.
Al primo errore la prova si interrompe; tempi ed errori sono nel risultato.
Versione Ollama e memoria usata dai modelli caricati sono rilevate automaticamente.
Viene registrata anche la configurazione del modello (template e controlli thinking).
Sedi e alcuni numeri di impianti non documentati sono segnalati nel risultato;
questi controlli sono limitati e non rilevano tutti gli errori clinici.
La v3 mantiene contesto 4096 e massimo 1500 token di risposta della v2;
questo puo' cambiare i risultati rispetto alla prova precedente.

Questa e' una prova iniziale, NON un modello addestrato.
I tre casi sono esempi fittizi adattati ai problemi discussi: non sono una
validazione clinica e non rappresentano tutta la casistica dello studio.
La validita' del JSON non e' un giudizio sulla correttezza clinica.
Gli aspetti attesi sono nel risultato, per la revisione da parte del medico;
non vengono mostrati al modello durante l'analisi.

Il programma usa soltanto http://127.0.0.1:11434 sul PC, senza proxy o redirect.
Non chiama OpenAI, non legge chiavi e non scrive nel gestionale.
Non sostituisce l'agente v8: tieni le due cartelle separate.
Non inserire trascrizioni reali in questo pacchetto di prova.

protocollo.json contiene una copia delle istruzioni e del formato usati
dalla comprensione API, per confrontare il modello locale sullo stesso compito.
Non trasferisce pesi o capacita' del modello OpenAI.
